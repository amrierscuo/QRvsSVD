%addpath data/
format short e

disp('Superficie1')
load superficie1.mat
[n, m] = size(M);

figure()
for i=1:m
    I = mat2gray(reshape(M(:, i), r, s));
    subplot(2, 4, i)
    imshow(I);
end

dataset = 0;
coreResolver

errorsName = {'errore fattorizzazione', 'errore assoluto della normale', 'errore relativo della normale', 'errore relativo della normale matlab','tempi'}; 

disp('Errori nelle normali superficie1')
tableErrorNsup = table(errorsName', date(:,1), date(:,2), date(:,3), date(:,4), date(:,5), 'VariableNames', {'Tipo','Normale','HouseHolder','Givens', 'Matlab', 'SVD'});
disp(tableErrorNsup)

disp('Conchiglia')
load conchiglia.mat
[n, m] = size(M);

figure()
for i=1:m
    I = mat2gray(reshape(M(:, i), s, r));
    subplot(5, 4, i)
    imshow(I);
end

dataset = 1;
coreResolver

m = 20;
n = 10;
times = 20;

arrayIndex = 1:times;
dimRow = ones(1,times);
dimColumn = ones(1,times);

errorSolm = ones(1,times);
errorSolh = ones(1,times);
errorSolg = ones(1,times);

errorSolOriginalm = ones(1,times);
errorSolOriginalh = ones(1,times);
errorSolOriginalg = ones(1,times);

tm = ones(1,times);
th = ones(1,times);
tg = ones(1,times);

errorQRm = ones(1,times);
errorQRh = ones(1,times);
errorQRg = ones(1,times);

errorQm = ones(1,times);
errorQh = ones(1,times);
errorQg = ones(1,times);

for i=1:times
    A = rand(m, n);
    x = rand(n,1);
    b = A * x;

    [errorSolm(i), tm(i), errorQRm(i), errorQm(i), errorSolOriginalm(i)] = ComputeErrors(@qr, A, x, b);

    [errorSolh(i), th(i), errorQRh(i), errorQh(i), errorSolOriginalh(i)] = ComputeErrors(@HouseHolderQR, A, x, b);

    [errorSolg(i), tg(i), errorQRg(i), errorQg(i), errorSolOriginalg(i)] = ComputeErrors(@GivensQR, A, x, b);

    m = m + 10;
    n = n + 10;

    dimRow(i) = m;
    dimColumn(i) = n;
end

dimensionByStep = table(dimRow, dimColumn);

figure
semilogy(arrayIndex, errorSolm, '--o', arrayIndex, errorSolh, '--o', arrayIndex, errorSolg, '--o');
title('Relative Residue part1');
xlabel('Step');
ylabel('Error');
legend('error matlab','error householder', 'error givens');

disp('Relative Residue Part 1 on the system')
tableErrorSystem = table(arrayIndex', errorSolm', errorSolh', errorSolg', 'VariableNames', {'Step','MatlabResidue','HouseHolderResidue','GivensResidue'});
disp(tableErrorSystem)

figure
semilogy(arrayIndex, errorSolOriginalm, '--o', arrayIndex, errorSolOriginalh, '--o', arrayIndex, errorSolOriginalg, '--o');
title('Relative Error part2');
xlabel('Step');
ylabel('Error');
legend('error matlab','error householder', 'error givens');

disp('Relative Error Part 2 on the original solution')
tableErrorOnSolution = table(arrayIndex', errorSolOriginalm', errorSolOriginalh', errorSolOriginalg', 'VariableNames', {'Step','MatlabError','HouseHolderError','GivensError'});
disp(tableErrorOnSolution)

figure
semilogy(arrayIndex, tm, '--o', arrayIndex, th, '--o', arrayIndex, tg, '--o');
title('Time');
xlabel('Step');
ylabel('Time');
legend('time matlab','time householder', 'time givens');

disp('Time')
tableTime = table(arrayIndex', tm', th', tg', 'VariableNames', {'Step','MatlabTime','HouseHolderTime','GivensTime'});
disp(tableTime)

figure
semilogy(arrayIndex, errorQRm, '--o', arrayIndex, errorQRh, '--o', arrayIndex, errorQRg, '--o');
title('Factoring error');
xlabel('Step');
ylabel('Error');
legend('error matlab','error householder', 'error givens');

disp('Factoring error')
tableErrorFactoring = table(arrayIndex', errorQRm', errorQRh', errorQRg', 'VariableNames', {'Step','MatlabError','HouseHolderError','GivensError'});
disp(tableErrorFactoring)

figure
semilogy(arrayIndex, errorQm, '--o', arrayIndex, errorQh, '--o', arrayIndex, errorQg, '--o');
title('Q error');
xlabel('Step');
ylabel('Error');
legend('error matlab','error householder', 'error givens');

disp('Error of Q matrix')
tableErrorQ = table(arrayIndex', errorQm', errorQh', errorQg', 'VariableNames', {'Step','MatlabError','HouseHolderError','GivensError'});
disp(tableErrorQ)

format short e

Ltrasp = L';
Mtrasp = M';

tic

[Qh, Rh] = HouseHolderQR(Ltrasp);

Nqrtesth = QRSystemResolution(Qh, Rh, Mtrasp);

timeH = toc;

tic
[Qg, Rg] = GivensQR(Ltrasp);

Nqrtestg = QRSystemResolution(Qg, Rg, Mtrasp);

timeG = toc;

tic

Nmatlab = Ltrasp\Mtrasp;

timeM = toc;

disp('')

errFatt = [norm(N'*L-M, inf), norm(Nqrtesth'*L-M, inf), norm(Nqrtestg'*L-M, inf), norm(Nmatlab'*L-M, inf)];

errN = [NaN, norm(N - Nqrtesth, inf), norm(N - Nqrtestg, inf), norm(N - Nmatlab, inf)];

errNRel = [NaN, norm(N - Nqrtesth, inf)/norm(N, inf), norm(N - Nqrtestg, inf)/norm(N, inf), norm(N - Nmatlab, inf)/norm(N, inf)];

disp('Errori nella ricostruzione della normale')
tableErrorNormale = table({'HouseHolderQR'; 'GivensQR'; 'MatlabQR'}, errFatt', errN', errNRel', 'VariableNames', {'Metodo', 'ErroreFattorizzazione', 'ErroreAssoluto', 'ErroreRelativo'});
disp(tableErrorNormale)

%% Funzione per calcolare gli errori e i tempi di esecuzione di un metodo di risoluzione di un sistema lineare
function [errorSol, t, errorQR, errorQ, errorSolOriginal] = ComputeErrors(method, A, x, b)
    tic
    [~, R] = method(A);
    errorQR = norm(A - Q * R, 'fro') / norm(A, 'fro');
    
    errorQ = norm(eye(size(A)) - Q' * Q, 'fro');
    
    x_sol = QRSystemResolution(Q, R, b);
    
    errorSol = norm(x - x_sol) / norm(x);
    
    errorSolOriginal = norm(A * x - A * x_sol) / norm(A * x);
    
    t = toc;
end

%% Funzione per risolvere il sistema lineare Ax = b dato la fattorizzazione QR di A
function x = QRSystemResolution(Q, R, b)
    y = Q' * b;
    x = R \ y;
end

%% Funzione per la fattorizzazione QR con il metodo di Householder
function [Q, R] = HouseHolderQR(A)
    [m, n] = size(A);
    Q = eye(m);
    R = A;
    for k = 1:n
        x = R(k:m, k);
        v = -sign(x(1)) * norm(x) * eye(1) - x;
        v = v / norm(v);
        R(k:m, k:n) = R(k:m, k:n) - 2 * v * (v' * R(k:m, k:n));
        Q(k:m, :) = Q(k:m, :) - 2 * v * (v' * Q(k:m, :));
    end
end

%% Funzione per la fattorizzazione QR con il metodo di Givens
function [Q, R] = GivensQR(A)
    [m, n] = size(A);
    Q = eye(m);
    R = A;
    for k = 1:n
        for i = m:-1:(k+1)
            G = eye(m);
            [c, s] = givensrotation(R(i-1, k), R(i, k));
            G([i-1, i], [i-1, i]) = [c, s; -s, c];
            R = G' * R;
            Q = Q * G;
        end
    end
end

%% Funzione per calcolare la rotazione di Givens
function [c, s] = givensrotation(a, b)
    if b == 0
        c = 1;
        s = 0;
    else
        if abs(b) > abs(a)
            r = a / b;
            s = 1 / sqrt(1 + r^2);
            c = s * r;
        else
            r = b / a;
            c = 1 / sqrt(1 + r^2);
            s = c * r;
        end
    end
end
