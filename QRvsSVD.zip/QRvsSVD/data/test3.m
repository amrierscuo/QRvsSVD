% Carica il dataset 'superficie1.mat'
load superficie1.mat

% Estrai le dimensioni delle immagini nel dataset
[n, m] = size(M);
r = 101; % Numero di righe in ogni immagine
s = 101; % Numero di colonne in ogni immagine

disp(['Dimensioni di M (superficie1): ', num2str(n), ' x ', num2str(m)]);
disp(['Dimensioni dell''immagine (superficie1): ', num2str(r), ' x ', num2str(s)]);
disp(['Numero di immagini in superficie1: ', num2str(m)]);

% Applica QR di Givens all'intero dataset
Qgivens = zeros(r, r, m);
Rgivens = zeros(r, r, m);
timeGivens = zeros(1, m);

% Applica QR di Householder all'intero dataset
Qhouseholder = zeros(r, r, m);
Rhouseholder = zeros(r, r, m);
timeHouseholder = zeros(1, m);

% Applica SVD all'intero dataset
Usvd = zeros(r, r, m);
Ssvd = zeros(r, m);
Vsvd = zeros(s, s, m);
timeSVD = zeros(1, m);

% Ricostruzioni 3D prima e dopo l'applicazione degli algoritmi
reconOriginal = zeros(r, s, m);
reconGivens = zeros(r, s, m);
reconHouseholder = zeros(r, s, m);
reconSVD = zeros(r, s, m);

for i = 1:m
    A = reshape(M(:, i), r, s);
    reconOriginal(:,:,i) = A;
    
    tic;
    [Q, R] = GivensQR(A);
    timeGivens(i) = toc;
    Qgivens(:,:,i) = Q;
    Rgivens(:,:,i) = R;
    reconGivens(:,:,i) = Q * R;
    
    tic;
    [Q, R] = HouseholderQR(A);
    timeHouseholder(i) = toc;
    Qhouseholder(:,:,i) = Q;
    Rhouseholder(:,:,i) = R;
    reconHouseholder(:,:,i) = Q * R;
    
    tic;
    [U, S, V] = svd(A);
    timeSVD(i) = toc;
    Usvd(:,:,i) = U(:,1:r);
    Ssvd(:,i) = diag(S(1:r,1:r));
    Vsvd(:,:,i) = V(:,1:s);
    reconSVD(:,:,i) = U * S * V';
end

% Mostra le ricostruzioni 3D prima e dopo l'applicazione degli algoritmi per tutte le immagini
for i = 1:m
    figure;
    subplot(2,2,1);
    surf(reconOriginal(:,:,i));
    title('Immagine originale');
    
    subplot(2,2,2);
    surf(reconGivens(:,:,i));
    title('QR di Givens');
    
    subplot(2,2,3);
    surf(reconHouseholder(:,:,i));
    title('QR di Householder');
    
    subplot(2,2,4);
    surf(reconSVD(:,:,i));
    title('SVD');
end

% Analisi delle dimensioni delle immagini
fprintf('\n--- Analisi delle dimensioni delle immagini ---\n');
fprintf('Numero di immagini: %d\n', m);
fprintf('Dimensione media immagine originale: %.2f\n', mean(n*m));
fprintf('Dimensione media QR di Givens: %.2f\n', mean(r*r + r*s));
fprintf('Dimensione media QR di Householder: %.2f\n', mean(2*r*s));
fprintf('Tempo medio di esecuzione QR di Givens: %.16f secondi\n', mean(timeGivens));
fprintf('Tempo medio di esecuzione QR di Householder: %.16f secondi\n', mean(timeHouseholder));
fprintf('Tempo medio di esecuzione SVD: %.16f secondi\n', mean(timeSVD));
fprintf('Deviazione standard QR di Givens: %.16f secondi\n', std(timeGivens));
fprintf('Deviazione standard QR di Householder: %.16f secondi\n', std(timeHouseholder));
fprintf('Deviazione standard SVD: %.16f secondi\n', std(timeSVD));

% Crea un grafico dei tempi di esecuzione (lineare e semilogaritmico)
figure;
subplot(2,1,1);
plot(1:m, timeGivens, 'r', 'LineWidth', 2);
hold on;
plot(1:m, timeHouseholder, 'b', 'LineWidth', 2);
plot(1:m, timeSVD, 'g', 'LineWidth', 2);
legend('QR di Givens', 'QR di Householder', 'SVD', 'Location', 'NorthWest');
xlabel('Indice dell''immagine');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione QR di Givens, QR di Householder e SVD');
grid on;
hold off;

subplot(2,1,2);
semilogy(1:m, timeGivens, 'r', 'LineWidth', 2);
hold on;
semilogy(1:m, timeHouseholder, 'b', 'LineWidth', 2);
semilogy(1:m, timeSVD, 'g', 'LineWidth', 2);
legend('QR di Givens', 'QR di Householder', 'SVD', 'Location', 'NorthWest');
xlabel('Indice dell''immagine');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione QR di Givens, QR di Householder e SVD (scala semilogaritmica)');
grid on;
hold off;

% Calcola gli errori di ricostruzione per QR di Givens
errorGivens = zeros(1, m);
for i = 1:m
    A = reshape(M(:, i), r, s);
    Q = Qgivens(:,:,i);
    R = Rgivens(:,:,i);
    reconstructed = Q * R;
    errorGivens(i) = norm(A - reconstructed, 'fro');
end

% Calcola gli errori di ricostruzione per QR di Householder
errorHouseholder = zeros(1, m);
for i = 1:m
    A = reshape(M(:, i), r, s);
    Q = Qhouseholder(:,:,i);
    R = Rhouseholder(:,:,i);
    reconstructed = Q * R;
    errorHouseholder(i) = norm(A - reconstructed, 'fro');
end

% Calcola gli errori di ricostruzione per SVD
errorSVD = zeros(1, m);
for i = 1:m
    A = reshape(M(:, i), r, s);
    U = Usvd(:,:,i);
    S = diag(Ssvd(:,i));
    V = Vsvd(:,:,i);
    reconstructed = U * S * V';
    errorSVD(i) = norm(A - reconstructed, 'fro');
end

% Crea un grafico degli errori di ricostruzione (lineare e semilogaritmico)
figure;
subplot(2,1,1);
plot(1:m, errorGivens, 'r', 'LineWidth', 2);
hold on;
plot(1:m, errorHouseholder, 'b', 'LineWidth', 2);
plot(1:m, errorSVD, 'g', 'LineWidth', 2);
legend('QR di Givens', 'QR di Householder', 'SVD', 'Location', 'NorthWest');
xlabel('Indice dell''immagine');
ylabel('Errore di ricostruzione');
title('Errori di ricostruzione per QR di Givens, QR di Householder e SVD');
grid on;
hold off;

subplot(2,1,2);
semilogy(1:m, errorGivens, 'r', 'LineWidth', 2);
hold on;
semilogy(1:m, errorHouseholder, 'b', 'LineWidth', 2);
semilogy(1:m, errorSVD, 'g', 'LineWidth', 2);
legend('QR di Givens', 'QR di Householder', 'SVD', 'Location', 'NorthWest');
xlabel('Indice dell''immagine');
ylabel('Errore di ricostruzione');
title('Errori di ricostruzione per QR di Givens, QR di Householder e SVD (scala semilogaritmica)');
grid on;
hold off;

% Calcola la percentuale di riduzione dell'errore di ricostruzione rispetto alle immagini originali
reductionGivens = (1 - errorGivens ./ norm(M, 'fro')) * 100;
reductionHouseholder = (1 - errorHouseholder ./ norm(M, 'fro')) * 100;
reductionSVD = (1 - errorSVD ./ norm(M, 'fro')) * 100;

fprintf('Percentuale media di riduzione dell''errore di ricostruzione:\n');
fprintf('QR di Givens: %.32f%%\n', mean(reductionGivens));
fprintf('QR di Householder: %.32f%%\n', mean(reductionHouseholder));
fprintf('SVD: %.32f%%\n', mean(reductionSVD));

% Calcola il rapporto tra la dimensione originale dell'immagine e la dimensione dei fattori Q e R per QR di Givens e QR di Householder
sizeQRGivens = r * (r + s) * m;
sizeQRHouseholder = 2 * r * s * m;

fprintf('Rapporto dimensioni QR di Givens: %.2f\n', sizeQRGivens / mean(n * m));
fprintf('Rapporto dimensioni QR di Householder: %.2f\n', sizeQRHouseholder / mean(n * m));

% Definizione della funzione GivensQR
function [Q, R] = GivensQR(A)
    [m, n] = size(A);
    Q = eye(m);
    R = A;
    for j = 1:n
        for i = m:-1:(j+1)
            G = eye(m);
            [c, s] = givensrotation(R(i-1, j), R(i, j));
            G([i-1, i], [i-1, i]) = [c, -s; s, c];
            R = G' * R;
            Q = Q * G;
        end
    end
end

% Funzione di supporto per la rotazione di Givens
function [c, s] = givensrotation(a, b)
    if b == 0
        c = sign(a);
        s = 0;
    elseif abs(b) > abs(a)
        t = -a / b;
        s = 1 / sqrt(1 + t^2);
        c = s * t;
    else
        t = -b / a;
        c = 1 / sqrt(1 + t^2);
        s = c * t;
    end
end

% Definizione della funzione HouseholderQR
function [Q, R] = HouseholderQR(A)
    [m, n] = size(A);
    R = A;
    Q = eye(m);
    for k = 1:min(m-1, n)
        x = R(k:m, k);
        [Ht, v] = HouseHolderMatrix(x);
        H = eye(m);
        H(k:m, k:m) = Ht;
        R = H * R;
        Q = Q * H;
    end
end

% Funzione di supporto per la matrice di Householder
function [Ht, v] = HouseHolderMatrix(x)
    n = length(x);
    v = zeros(n, 1);
    v(1) = x(1) + sign(x(1)) * norm(x);
    v = v / norm(v);
    Ht = eye(n) - 2 * (v * v');
end


