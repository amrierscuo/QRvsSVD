% File: SVD_QRPerformanceAnalysis.m
% Init
sizes = 10:10:100;  % Dimensioni delle matrici
nSizes = length(sizes);

% Preallocazione
householderTime = zeros(1, nSizes);
givensTime = zeros(1, nSizes);
svdTime = zeros(1, nSizes); % Tempo di esecuzione per SVD
backslashTime = zeros(1, nSizes); % Tempo di esecuzione per A\b
condNum = zeros(1, nSizes);
residualNorm = zeros(3, nSizes);  % Calcolo della norma del residuo
absError = zeros(3, nSizes);  % Calcolo dell'errore di ricostruzione

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice sovradeterminata (m > n) a rango pieno
    m = sizes(i) * 2;
    n = sizes(i);
    rankA = n;  % Rango pieno
    A = randn(m, n);
    A(:, rankA+1:end) = 0;  % Riduci gli elementi oltre il rango a 0
    b = rand(m, 1);  % vettore dei termini noti

    fprintf('\nMatrice A di dimensione %d x %d e rango %d:\n', m, n, rankA);
    disp(A);
    
    % Householder QR
    tic;
    [Q, R] = HouseHolderQR(A);
    x = R \ (Q' * b);  % Risolvi il sistema con operatore \
    householderTime(i) = toc;
    
    % Calcolo del residuo e dell'errore di ricostruzione per Householder
    residual = A * x - b;
    residualNorm(1, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(1, i) = norm(A(:, 1:rankA) - A_ricostruita(:, 1:rankA), 'fro');
    
    % Givens QR
    tic;
    [Q, R] = GivensQR(A);
    x = R \ (Q' * b);  % Risolvi il sistema con operatore \
    givensTime(i) = toc;
    
    % Calcolo del residuo e dell'errore di ricostruzione per Givens
    residual = A * x - b;
    residualNorm(2, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(2, i) = norm(A(:, 1:rankA) - A_ricostruita(:, 1:rankA), 'fro');
    
    % SVD
    tic;
    [U, S, V] = svd(A);
    x = V * (S \ (U' * b));  % Risolvi il sistema con operatore \
    svdTime(i) = toc;
    
    % Calcolo del residuo e dell'errore di ricostruzione per SVD
    residual = A * x - b;
    residualNorm(3, i) = norm(residual, 2);
    A_ricostruita = U(:, 1:rankA) * S(1:rankA, 1:rankA) * V(:, 1:rankA)';
    absError(3, i) = norm(A(:, 1:rankA) - A_ricostruita, 'fro');
    
    % Calcolo del numero di condizionamento
    condNum(i) = cond(A);
    
    % Analisi delle dimensioni delle matrici
    fprintf('\n--- Analisi delle dimensioni delle matrici ---\n');
    fprintf('Dimensione: %d x %d e rango %d\n', m, n, rankA);
    fprintf('Tempo di esecuzione ultima matrice (Householder): %.16f secondi\n', householderTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Householder): %.16f secondi\n', mean(householderTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (Givens): %.16f secondi\n', givensTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Givens): %.16f secondi\n', mean(givensTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (SVD): %.16f secondi\n', svdTime(i)); 
    fprintf('Tempo medio di esecuzione tra tutte le matrici(SVD): %.16f secondi\n', mean(svdTime(1:i))); 
    fprintf('Norma del residuo medio per Householder: %e\n', mean(residualNorm(1,:)));
    fprintf('Norma del residuo medio per Givens: %e\n', mean(residualNorm(2,:)));
    fprintf('Norma del residuo medio per SVD: %e\n', mean(residualNorm(3,:)));
    fprintf('Errore medio di ricostruzione per Householder: %e\n', mean(absError(1,:)));
    fprintf('Errore medio di ricostruzione per Givens: %e\n', mean(absError(2,:)));
    fprintf('Errore medio di ricostruzione per SVD: %e\n', mean(absError(3,:)));
    fprintf('Numero di condizionamento ultima matrice: %.16f \n', condNum(i));
    fprintf('Media dei numeri di condizionamento tra tutte le matrici: %.16f \n', mean(condNum(1:i)));
end

% Crea un grafico dei tempi di esecuzione
figure;
plot(sizes, householderTime, 'r', 'LineWidth', 2);
hold on;
plot(sizes, givensTime, 'b', 'LineWidth', 2);
plot(sizes, svdTime, 'g', 'LineWidth', 2);
plot(sizes, backslashTime, 'c', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Backslash', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione Householder, Givens, SVD e Backslash');
grid on;
hold off;

% Crea un grafico per la norma del residuo
figure;
plot(sizes, residualNorm(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, residualNorm(2,:), 'b', 'LineWidth', 2);
plot(sizes, residualNorm(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Norma del residuo');
title('Norma del residuo per Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per l'errore di ricostruzione
figure;
plot(sizes, absError(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, absError(2,:), 'b', 'LineWidth', 2);
plot(sizes, absError(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione');
title('Errore di ricostruzione per Householder, Givens e SVD');
grid on;
hold off;
