% Dimensioni delle matrici
sizes = [2 4 6];
nSizes = length(sizes);

% Preallocazione
householderTime = zeros(1, nSizes);
givensTime = zeros(1, nSizes);
svdTime = zeros(1, nSizes);
condNum = zeros(1, nSizes);
residualNorm = zeros(3, nSizes);
absError = zeros(3, nSizes);

% Contatore delle matrici con rango non pieno
matriciConRangoNonPieno = 0;

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice random di dimensioni (m x n)
    m = sizes(i) * 2;
    n = sizes(i) / 2;
    
    % Genera una matrice random di dimensioni (m x n)
    A = rand(m, n);
    
    % Applica la decomposizione SVD
    [U, S, V] = svd(A);
    
    % Riduci il rango della matrice
    minRank = min(m, n);
    desiredRank = minRank - 1; % Rango desiderato (un numero inferiore al rango minimo)
    S(desiredRank+1:end, desiredRank+1:end) = 0;
    
    % Ricostruisci la matrice a rango non pieno
    A = U * S * V';
    
    if sprank(A) < minRank
        matriciConRangoNonPieno = matriciConRangoNonPieno + 1;
    end
    
    b = rand(m, 1); % Vettore dei termini noti

    fprintf('\nMatrice A di dimensione %d x %d e rango %d:\n', m, n, sprank(A));
    disp(A);

    % Householder QR
    tic;
    [Q, R] = HouseHolderQR(A);
    x = R \ (Q' * b);
    householderTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Householder
    residual = A * x - b;
    residualNorm(1, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(1, i) = norm(A - A_ricostruita, 'fro');

    % Givens QR
    tic;
    [Q, R] = GivensQR(A);
    x = R \ (Q' * b);
    givensTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Givens
    residual = A * x - b;
    residualNorm(2, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(2, i) = norm(A - A_ricostruita, 'fro');

    % SVD
    tic;
    [U, S, V] = svd(A);
    x = V * (S \ (U' * b));
    svdTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per SVD
    residual = A * x - b;
    residualNorm(3, i) = norm(residual, 2);
    A_ricostruita = U * S * V';
    absError(3, i) = norm(A - A_ricostruita, 'fro');

    % Calcolo del numero di condizionamento
    if m == n
        condNum(i) = cond(A);
    else
        [~, S, ~] = svd(A);
        condNum(i) = max(diag(S)) / min(diag(S));
    end

    % Analisi delle dimensioni delle matrici
    fprintf('\n--- Analisi delle dimensioni delle matrici ---\n');
    fprintf('Dimensione: %d x %d e rango %d\n', m, n, sprank(A));
    fprintf('Tempo di esecuzione ultima matrice (Householder): %.16f secondi\n', householderTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Householder): %.16f secondi\n', mean(householderTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (Givens): %.16f secondi\n', givensTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Givens): %.16f secondi\n', mean(givensTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (SVD): %.16f secondi\n', svdTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(SVD): %.16f secondi\n', mean(svdTime(1:i)));
    fprintf('Norma del residuo medio: Householder: %.16f, Givens: %.16f, SVD: %.16f\n', mean(residualNorm(1,:)), mean(residualNorm(2,:)), mean(residualNorm(3,:)));
    fprintf('Errore medio di ricostruzione per Householder: %e\n', mean(absError(1,:)));
    fprintf('Errore medio di ricostruzione per Givens: %e\n', mean(absError(2,:)));
    fprintf('Errore medio di ricostruzione per SVD: %e\n', mean(absError(3,:)));
    fprintf('Numero di condizionamento ultima matrice: %.16f \n', condNum(i));
    fprintf('Media dei numeri di condizionamento tra tutte le matrici: %.16f \n', mean(condNum(1:i)));
end

% Calcola la percentuale di matrici con rango non pieno
percentualeRangoNonPieno = matriciConRangoNonPieno / nSizes * 100;

% Crea un grafico dei tempi di esecuzione
figure;
plot(sizes, householderTime, 'r', 'LineWidth', 2);
hold on;
plot(sizes, givensTime, 'b', 'LineWidth', 2);
plot(sizes, svdTime, 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per l'errore di ricostruzione
figure;
plot(sizes, absError(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, absError(2,:), 'b', 'LineWidth', 2);
plot(sizes, absError(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione');
title('Errore di ricostruzione per Householder, Givens e SVD');
grid on;
hold off;

% Stampa il numero di matrici con rango non pieno
fprintf('Numero di matrici con rango non pieno: %d/%d (%.2f%%)\n', matriciConRangoNonPieno, nSizes, percentualeRangoNonPieno);
