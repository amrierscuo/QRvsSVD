% SVD_QRPerformanceAnalysisSovradimensionateKPieno.m
% Dimensioni delle matrici
sizes = 2:2:6;
nSizes = length(sizes);

% Preallocazione
rankA = max(sizes);
householderTime = zeros(1, nSizes);
givensTime = zeros(1, nSizes);
svdTime = zeros(1, nSizes);
condNum = zeros(1, nSizes);
residualNorm = zeros(3, nSizes);
absError = zeros(3, nSizes);
minNormResidual = zeros(3, nSizes);

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice rettangolare sovradimensionata a rango pieno
    m = sizes(i) * 2;
    n = sizes(i);
    A = randn(m, n);
    A(:, n+1:end) = 0; % Riduci gli elementi oltre il rango a 0
    b = rand(m, 1); % Vettore dei termini noti

    fprintf('\nMatrice A di dimensione %d x %d e rango %d:\n', m, n, n);
    disp(A);

    % Householder QR
    tic;
    [Q, R] = HouseHolderQR(A);
    x = R \ (Q' * b);
    householderTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Householder
    residual = A * x - b;
    residualNorm(1, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(1, i) = norm(A - A_ricostruita, 'fro');
    minNormResidual(1, i) = norm(A_ricostruita*x - b, 2);

    % Givens QR
    tic;
    [Q, R] = GivensQR(A);
    x = R \ (Q' * b);
    givensTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Givens
    residual = A * x - b;
    residualNorm(2, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(2, i) = norm(A - A_ricostruita, 'fro');
    minNormResidual(2, i) = norm(A_ricostruita*x - b, 2);

    % SVD
    tic;
    [U, S, V] = svd(A);
    x = V * (S \ (U' * b));
    svdTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per SVD
    residual = A * x - b;
    residualNorm(3, i) = norm(residual, 2);
    A_ricostruita = U(:, 1:n) * S(1:n, 1:n) * V(:, 1:n)';
    absError(3, i) = norm(A - A_ricostruita, 'fro');
    minNormResidual(3, i) = norm(A_ricostruita*x - b, 2);

    % Calcolo del numero di condizionamento
    condNum(i) = cond(A);

    % Analisi delle dimensioni delle matrici
    fprintf('\n--- Analisi delle dimensioni delle matrici ---\n');
    fprintf('Dimensione: %d x %d e rango %d\n', m, n, n);
    fprintf('Tempo di esecuzione ultima matrice (Householder): %.16f secondi\n', householderTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Householder): %.16f secondi\n', mean(householderTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (Givens): %.16f secondi\n', givensTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Givens): %.16f secondi\n', mean(givensTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (SVD): %.16f secondi\n', svdTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(SVD): %.16f secondi\n', mean(svdTime(1:i)));
    fprintf('Norma del residuo medio: Householder: %.16f, Givens: %.16f, SVD: %.16f\n', mean(residualNorm(1,:)), mean(residualNorm(2,:)), mean(residualNorm(3,:)));
    fprintf('Errore medio di ricostruzione per Householder: %e\n', mean(absError(1,:)));
    fprintf('Errore medio di ricostruzione per Givens: %e\n', mean(absError(2,:)));
    fprintf('Errore medio di ricostruzione per SVD: %e\n', mean(absError(3,:)));
    fprintf('Numero di condizionamento ultima matrice: %.16f \n', condNum(i));
    fprintf('Media dei numeri di condizionamento tra tutte le matrici: %.16f \n', mean(condNum(1:i)));
    fprintf('Min norm ||Ax - b||2 per Householder: %.16f\n', minNormResidual(1, i));
    fprintf('Min norm ||Ax - b||2 per Givens: %.16f\n', minNormResidual(2, i));
    fprintf('Min norm ||Ax - b||2 per SVD: %.16f\n', minNormResidual(3, i));
end

% Crea un grafico dei tempi di esecuzione
figure;
plot(sizes, householderTime, 'r', 'LineWidth', 2);
hold on;
plot(sizes, givensTime, 'b', 'LineWidth', 2);
plot(sizes, svdTime, 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per l'errore di ricostruzione
figure;
plot(sizes, absError(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, absError(2,:), 'b', 'LineWidth', 2);
plot(sizes, absError(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione');
title('Errore di ricostruzione per Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per la min norm ||Ax - b||2
figure;
plot(sizes, minNormResidual(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, minNormResidual(2,:), 'b', 'LineWidth', 2);
plot(sizes, minNormResidual(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Min norm ||Ax - b||2');
title('Min norm ||Ax - b||2 per Householder, Givens e SVD');
grid on;
hold off;
