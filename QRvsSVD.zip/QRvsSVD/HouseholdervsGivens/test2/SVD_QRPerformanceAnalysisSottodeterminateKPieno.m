% SVD_QRPerformanceAnalysisSottodeterminateKPieno.m
% Dimensioni delle matrici
sizes = 10:10:100;
nSizes = length(sizes);

% Preallocazione
rankA = min(sizes);
householderTime = zeros(1, nSizes);
givensTime = zeros(1, nSizes);
svdTime = zeros(1, nSizes);
condNum = zeros(1, nSizes);
residualNorm = zeros(3, nSizes);
absError = zeros(3, nSizes);
minNormX = zeros(3, nSizes);

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice rettangolare sottodeterminata a rango minimo
    m = sizes(i);
    n = sizes(i) * 2;
    A = randn(m, n);
    b = randn(m, 1); % Vettore dei termini noti corretto

    fprintf('\nMatrice A di dimensione %d x %d e rango %d:\n', m, n, m);
    disp(A);

    % Householder QR
    tic;
    [Q, R] = HouseholderQR(A);
    if n <= rankA
        x = pinv(R(1:n, 1:n)) * (Q' * b);
    else
        x = pinv(R) * (Q' * b);
    end
    householderTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Householder
    residual = A * x - b;
    residualNorm(1, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(1, i) = norm(A - A_ricostruita, 'fro');
    minNormX(1, i) = norm(x, 2);

    % Givens QR
    tic;
    [Q, R] = GivensQR(A);
    if n <= rankA
        x = pinv(R(1:n, 1:n)) * (Q' * b);
    else
        x = pinv(R) * (Q' * b);
    end
    givensTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per Givens
    residual = A * x - b;
    residualNorm(2, i) = norm(residual, 2);
    A_ricostruita = Q * R;
    absError(2, i) = norm(A - A_ricostruita, 'fro');
    minNormX(2, i) = norm(x, 2);

    % SVD
    tic;
    [U, S, V] = svd(A);
    x = V(:, 1:m) * (pinv(S(1:m, 1:m)) * (U(:, 1:m)' * b));
    svdTime(i) = toc;

    % Calcolo del residuo e dell'errore di ricostruzione per SVD
    residual = A * x - b;
    residualNorm(3, i) = norm(residual, 2);
    A_ricostruita = U(:, 1:m) * S(1:m, 1:m) * V(:, 1:m)';
    absError(3, i) = norm(A - A_ricostruita, 'fro');
    minNormX(3, i) = norm(x, 2);

    % Calcolo del numero di condizionamento
    condNum(i) = cond(A);

    % Analisi delle dimensioni delle matrici
    fprintf('\n--- Analisi delle dimensioni delle matrici ---\n');
    fprintf('Dimensione: %d x %d e rango %d\n', m, n, m);
    fprintf('Tempo di esecuzione ultima matrice (Householder): %.16f secondi\n', householderTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici (Householder): %.16f secondi\n', mean(householderTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (Givens): %.16f secondi\n', givensTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici (Givens): %.16f secondi\n', mean(givensTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (SVD): %.16f secondi\n', svdTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici (SVD): %.16f secondi\n', mean(svdTime(1:i)));
    fprintf('Norma del residuo medio: Householder: %.16f, Givens: %.16f, SVD: %.16f\n', mean(residualNorm(1,:)), mean(residualNorm(2,:)), mean(residualNorm(3,:)));
    fprintf('Errore medio di ricostruzione per Householder: %e\n', mean(absError(1,:)));
    fprintf('Errore medio di ricostruzione per Givens: %e\n', mean(absError(2,:)));
    fprintf('Errore medio di ricostruzione per SVD: %e\n', mean(absError(3,:)));
    fprintf('Numero di condizionamento ultima matrice: %.16f\n', condNum(i));
    fprintf('Media dei numeri di condizionamento tra tutte le matrici: %.16f\n', mean(condNum(1:i)));
    fprintf('Min norm ||x|| per Householder: %.16f\n', minNormX(1, i));
    fprintf('Min norm ||x|| per Givens: %.16f\n', minNormX(2, i));
    fprintf('Min norm ||x|| per SVD: %.16f\n', minNormX(3, i));
end

% Crea un grafico dei tempi di esecuzione
figure;
plot(sizes, householderTime, 'r', 'LineWidth', 2);
hold on;
plot(sizes, givensTime, 'b', 'LineWidth', 2);
plot(sizes, svdTime, 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per l'errore di ricostruzione
figure;
plot(sizes, absError(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, absError(2,:), 'b', 'LineWidth', 2);
plot(sizes, absError(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione');
title('Errore di ricostruzione per Householder, Givens e SVD');
grid on;
hold off;

% Crea un grafico per la min norm ||x||
figure;
plot(sizes, minNormX(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, minNormX(2,:), 'b', 'LineWidth', 2);
plot(sizes, minNormX(3,:), 'g', 'LineWidth', 2);
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest');
xlabel('Dimensione della matrice');
ylabel('Min norm ||x||');
title('Min norm ||x|| per Householder, Givens e SVD');
grid on;
hold off;

% GivensQR.m
function [Q, R] = GivensQR(A)
    [m, n] = size(A);
    R = A;
    G = eye(m);

    for k = 1:min(m, n)
        for i = k+1:m
            [c, s] = GivRot(R(k, k), R(i, k));
            for j = k:n
                t = c * R(k, j) + s * R(i, j);
                R(i, j) = -s * R(k, j) + c * R(i, j);
                R(k, j) = t;
            end
            G = GMatrix(c, s, k, i, m) * G;
        end
    end

    Q = G';
end

function [c, s] = GivRot(a, b)
    r = sqrt(a^2 + b^2);
    c = a / r;
    s = b / r;
end

function G = GMatrix(c, s, k, i, m)
    G = eye(m);
    G(k, k) = c;
    G(i, i) = c;
    G(k, i) = s;
    G(i, k) = -s;
end

% HouseholderQR.m
function [Q, R] = HouseholderQR(A)
    [m, n] = size(A);
    Q = eye(m);
    R = A;

    for i = 1:min(m, n)
        X = R(i:m, i);
        [Ht, ~] = HouseholderMatrix(X);
        H = [eye(i-1) zeros(i-1, m-i+1); zeros(m-i+1, i-1) Ht];
        R = H * R;
        Q = Q * H;
    end
end

function [Ht, k] = HouseholderMatrix(x)
    n = length(x);
    e1 = zeros(n, 1);
    e1(1) = 1;
    k = sign(x(1)) * norm(x);
    v = x + k * e1;
    Ht = eye(n) - 2 * (v * v') / (v' * v);
end
