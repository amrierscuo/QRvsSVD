% File: SVD_QRPerformanceAnalysis.m
% Init
sizes = 10:10:100;  % Dimensioni delle matrici
nSizes = length(sizes);

% Preallocazione
householderTime = zeros(1, nSizes);
givensTime = zeros(1, nSizes);
svdTime = zeros(1, nSizes); % Tempo di esecuzione per SVD
condNum = zeros(1, nSizes);
normAQR = zeros(3, nSizes); 
normQQT = zeros(3, nSizes); 
absError = zeros(3, nSizes); 

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice di Hilbert
    A = hilb(sizes(i));
    
    fprintf('\nMatrice A di dimensione %d:\n', sizes(i));
    disp(A);
    
    % Householder QR
    tic;
    [Q, R] = HouseHolderQR(A);
    householderTime(i) = toc;
    
    % Calcoli per Householder
    A_ricostruita = Q * R;
    normAQR(1, i) = norm(A - A_ricostruita, inf);
    normQQT(1, i) = norm(Q*Q' - eye(size(Q,1)), inf);
    absError(1, i) = norm(A - A_ricostruita, 'fro');
    
    % Givens QR
    tic;
    [Q, R] = GivensQR(A);
    givensTime(i) = toc;
    
    % Calcoli per Givens
    A_ricostruita = Q * R;
    normAQR(2, i) = norm(A - A_ricostruita, inf);
    normQQT(2, i) = norm(Q*Q' - eye(size(Q,1)), inf);
    absError(2, i) = norm(A - A_ricostruita, 'fro');
    
    % SVD
    tic;
    [U, S, V] = svd(A);
    svdTime(i) = toc;
    
    % Calcoli per SVD
    A_ricostruita = U * S * V';
    normAQR(3, i) = norm(A - A_ricostruita, inf);
    normQQT(3, i) = norm(U*U' - eye(size(U,1)), inf); % Per SVD, Q diventa U
    absError(3, i) = norm(A - A_ricostruita, 'fro');
    
    % Calcolo dell'errore di ricostruzione relativo
    relError = norm(A - A_ricostruita, 'fro') / norm(A, 'fro');
    
    fprintf('Errore relativo di ricostruzione: %.16f\n', relError);
    
    % Calcolo del numero di condizionamento
    condNum(i) = cond(A);
    
    % Analisi delle dimensioni delle matrici
    fprintf('\n--- Analisi delle dimensioni delle matrici ---\n');
    fprintf('Dimensione: %d\n', sizes(i));
    fprintf('Tempo di esecuzione ultima matrice (Householder): %.16f secondi\n', householderTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Householder): %.16f secondi\n', mean(householderTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (Givens): %.16f secondi\n', givensTime(i));
    fprintf('Tempo medio di esecuzione tra tutte le matrici(Givens): %.16f secondi\n', mean(givensTime(1:i)));
    fprintf('Tempo di esecuzione ultima matrice (SVD): %.16f secondi\n', svdTime(i)); 
    fprintf('Tempo medio di esecuzione tra tutte le matrici(SVD): %.16f secondi\n', mean(svdTime(1:i))); 
    fprintf('Errore medio di ricostruzione per Householder: %e\n', mean(absError(1,:)));
    fprintf('Errore medio di ricostruzione per Givens: %e\n', mean(absError(2,:)));
    fprintf('Errore medio di ricostruzione per SVD: %e\n', mean(absError(3,:)));
    fprintf('Numero di condizionamento ultima matrice: %.16f \n', condNum(i));
    fprintf('Media dei numeri di condizionamento tra tutte le matrici: %.16f \n', mean(condNum(1:i)));
    fprintf('Media ||A-QR||∞: %e\n', mean(normAQR(:, i)));
    fprintf('Media ||QQ^T-I||∞: %e\n', mean(normQQT(:, i)));
    fprintf('Media Errore assoluto di ricostruzione: %e\n', mean(absError(:, i)));
end

% Crea un grafico dei tempi di esecuzione
figure;
plot(sizes, householderTime, 'r', 'LineWidth', 2);
hold on;
plot(sizes, givensTime, 'b', 'LineWidth', 2);
plot(sizes, svdTime, 'g', 'LineWidth', 2); % Aggiungere SVD
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest'); % Aggiungere SVD
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione (secondi)');
title('Tempi di esecuzione Householder, Givens e SVD'); % Aggiungere SVD
grid on;

% Crea un grafico per l'errore di ricostruzione relativo
figure;
plot(sizes, normAQR(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, normAQR(2,:), 'b', 'LineWidth', 2);
plot(sizes, normAQR(3,:), 'g', 'LineWidth', 2); % Aggiungere SVD
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest'); % Aggiungere SVD
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione relativo');
title('Errore di ricostruzione relativo Householder, Givens e SVD'); % Aggiungere SVD
grid on;

% Crea un grafico per ||A-QR||∞
figure;
plot(sizes, normAQR(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, normAQR(2,:), 'b', 'LineWidth', 2);
plot(sizes, normAQR(3,:), 'g', 'LineWidth', 2); % Aggiungere SVD
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest'); % Aggiungere SVD
xlabel('Dimensione della matrice');
ylabel('||A-QR||∞');
title('||A-QR||∞ per Householder, Givens e SVD'); % Aggiungere SVD
grid on;
hold off;

% Crea un grafico per ||QQ^T-I||∞
figure;
plot(sizes, normQQT(1,:), 'r', 'LineWidth', 2);
hold on;
plot(sizes, normQQT(2,:), 'b', 'LineWidth', 2);
plot(sizes, normQQT(3,:), 'g', 'LineWidth', 2); % Aggiungere SVD
legend('Householder', 'Givens', 'SVD', 'Location', 'NorthWest'); % Aggiungere SVD
xlabel('Dimensione della matrice');
ylabel('||QQ^T-I||∞');
title('||QQ^T-I||∞ per Householder, Givens e SVD'); % Aggiungere SVD
grid on;
hold off;

% Mostra tutti i grafici
hold off;
