% File: QRPerformanceAnalysis2.m
% Init
sizes = 10:10:100;  % Dimensioni delle matrici
nSizes = length(sizes);

% Preallocazione
qrTime = zeros(nSizes, 1);
svdTime = zeros(nSizes, 1);
condNumQR = zeros(nSizes, 1);
condNumSVD = zeros(nSizes, 1);
rankA = zeros(nSizes, 1);
normAQR = zeros(nSizes, 1);
normQQT = zeros(nSizes, 1);
absErrorQR = zeros(nSizes, 1);
absErrorSVD = zeros(nSizes, 1);

% Ciclo attraverso le dimensioni delle matrici
for i = 1:nSizes
    % Genera una matrice casuale sottodeterminata
    A_sottodet = randn(sizes(i) - 1, sizes(i));
    
    % QR decomposition per matrice sottodeterminata
    tic;
    [Q_sottodet, R_sottodet] = qr(A_sottodet);
    qrTime(i) = toc;
    
    % Calcoli per QR decomposition
    A_ricostruita_sottodet = Q_sottodet * R_sottodet;
    normAQR(i) = norm(A_sottodet - A_ricostruita_sottodet, inf);
    normQQT(i) = norm(Q_sottodet * Q_sottodet' - eye(size(Q_sottodet, 1)), inf);
    absErrorQR(i) = norm(A_sottodet - A_ricostruita_sottodet, 'fro');
    
    % Calcolo del numero di condizionamento
    condNumQR(i) = cond(A_sottodet);
    
    % Calcolo del rango della matrice
    rankA(i) = rank(A_sottodet);
    
    % Genera una matrice casuale sovradeterminata
    A_sovradet = randn(sizes(i), sizes(i) - 1);
    
    % QR decomposition per matrice sovradeterminata
    tic;
    [Q_sovradet, R_sovradet] = qr(A_sovradet);
    qrTime(i) = qrTime(i) + toc;
    
    % Calcoli per QR decomposition
    A_ricostruita_sovradet = Q_sovradet * R_sovradet;
    normAQR(i) = normAQR(i) + norm(A_sovradet - A_ricostruita_sovradet, inf);
    normQQT(i) = normQQT(i) + norm(Q_sovradet * Q_sovradet' - eye(size(Q_sovradet, 1)), inf);
    absErrorQR(i) = absErrorQR(i) + norm(A_sovradet - A_ricostruita_sovradet, 'fro');
    
    % Calcolo del numero di condizionamento
    condNumQR(i) = condNumQR(i) + cond(A_sovradet);
    
    % Calcolo del rango della matrice
    rankA(i) = rankA(i) + rank(A_sovradet);
    
    % Genera una matrice casuale quadrata
    A_quadrata = randn(sizes(i));
    
    % QR decomposition per matrice quadrata
    tic;
    [Q_quadrata, R_quadrata] = qr(A_quadrata);
    qrTime(i) = qrTime(i) + toc;
    
    % Calcoli per QR decomposition
    A_ricostruita_quadrata = Q_quadrata * R_quadrata;
    normAQR(i) = normAQR(i) + norm(A_quadrata - A_ricostruita_quadrata, inf);
    normQQT(i) = normQQT(i) + norm(Q_quadrata * Q_quadrata' - eye(size(Q_quadrata, 1)), inf);
    absErrorQR(i) = absErrorQR(i) + norm(A_quadrata - A_ricostruita_quadrata, 'fro');
    
    % Calcolo del numero di condizionamento
    condNumQR(i) = condNumQR(i) + cond(A_quadrata);
    
    % Calcolo del rango della matrice
    rankA(i) = rankA(i) + rank(A_quadrata);
    
    % SVD decomposition solo per matrice quadrata
    tic;
    [U, S, V] = svd(A_quadrata);
    svdTime(i) = toc;
    
    % Calcoli per SVD decomposition
    A_ricostruita_svd = U * S * V';
    absErrorSVD(i) = norm(A_quadrata - A_ricostruita_svd, 'fro');
    
    % Calcolo del numero di condizionamento
    condNumSVD(i) = cond(A_quadrata);
end

% Calcolo delle medie
meanqrTime = mean(qrTime);
meansvdTime = mean(svdTime);
meancondNumQR = mean(condNumQR);
meancondNumSVD = mean(condNumSVD);
meanrankA = round(mean(rankA));
meannormAQR = mean(normAQR);
meannormQQT = mean(normQQT);
meanabsErrorQR = mean(absErrorQR);
meanabsErrorSVD = mean(absErrorSVD);

% Analisi delle prestazioni
fprintf('\n--- Analisi delle prestazioni ---\n');
fprintf('Media Tempo di esecuzione (QR): %.16f secondi\n', meanqrTime);
fprintf('Media Tempo di esecuzione (SVD): %.16f secondi\n', meansvdTime);
fprintf('Media Numero di condizionamento (QR): %.16f \n', meancondNumQR);
fprintf('Media Numero di condizionamento (SVD): %.16f \n', meancondNumSVD);
fprintf('Media Rango della matrice: %d \n', meanrankA);
fprintf('Media Errore assoluto di ricostruzione (QR): %e\n', meanabsErrorQR);
fprintf('Media Errore assoluto di ricostruzione (SVD): %e\n', meanabsErrorSVD);
fprintf('\n');

% Crea un grafico del tempo di esecuzione
figure;
plot(sizes, qrTime, '-ro');
hold on;
plot(sizes, svdTime, '-bo');
xlabel('Dimensione della matrice');
ylabel('Tempo di esecuzione');
title('Tempi di esecuzione per i casi Sottodeterminato, Sovradeterminato, Quadrato');
legend('QR', 'SVD');
grid on;
hold off;

% Crea un grafico dell'errore di ricostruzione relativo
figure;
plot(sizes(1:end-1), normAQR(1:end-1), '-ro');
hold on;
plot(sizes, absErrorSVD, '-bo');
xlabel('Dimensione della matrice');
ylabel('Errore di ricostruzione relativo');
title('Errore di ricostruzione relativo per i casi Sottodeterminato, Sovradeterminato, Quadrato');
legend('QR', 'SVD');
grid on;
hold off;


% Crea un grafico del numero di condizionamento
figure;
plot(sizes, condNumQR, '-ro');
hold on;
plot(sizes, condNumSVD, '-bo');
xlabel('Dimensione della matrice');
ylabel('Numero di condizionamento');
title('Numero di condizionamento per i casi Sottodeterminato, Sovradeterminato, Quadrato');
legend('QR', 'SVD');
grid on;
hold off;
